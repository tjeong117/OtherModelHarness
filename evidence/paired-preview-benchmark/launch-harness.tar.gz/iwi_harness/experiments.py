"""Public greedy-answer experiments on the current target, optionally with a temporary intervention."""

import hashlib
import json
import math
from pathlib import Path

import torch
from torch import nn

from .probes import _integer


MAX_CASES, MAX_NEW_TOKENS, MAX_DISPLAY = 6, 32, 160
_NATIVE_MLPS = {
    ("transformers.models.gemma3.modeling_gemma3", "Gemma3MLP"),
    ("transformers.models.qwen2.modeling_qwen2", "Qwen2MLP"),
}


def behavior_tool(internal):
    """Return the tool description and transport schema for this arm."""
    from .tools import INDEX, PROMPT, TOKEN_PAIR, arr, integer, obj

    case = obj({"prompt": PROMPT, "answers": arr({"type": "string", "minLength": 1,
                                                  "maxLength": 512}, 6),
                "slice": {"enum": ["improve", "preserve"]}}, ["prompt", "answers", "slice"])
    fields = {"cases": arr(case, MAX_CASES), "max_new_tokens": integer(1, MAX_NEW_TOKENS),
              "token_ids": TOKEN_PAIR}
    desc = ("Score public improve/preserve prompts using greedy answers and whitespace-trimmed exact "
            "match. A length-limited answer is flagged. An optional [wanted, alternative] pair "
            "adds its first-step logit margin. Use public examples only.")
    if internal:
        scale = {"type": "number", "minimum": -16, "maximum": 16}
        fields["intervention"] = {"anyOf": [
            obj({"kind": {"const": "native"}, "layer": integer(0, 1024), "unit": INDEX,
                 "scale": scale}, ["layer", "scale"]),
            obj({"kind": {"const": "sae"}, "layer": integer(0, 1024), "feature": INDEX,
                 "scale": scale}, ["kind", "feature", "scale"]),
        ]}
        desc += (" Optionally scale one gated MLP input to down_proj across every position and "
                 "generation step. Give layer, scale and optional unit (default: largest absolute "
                 "activation at the first prompt's last position). A verified dense native site "
                 "returns a corresponding weight-column write. Alternatively supply kind=sae, "
                 "feature and scale for the active residual dictionary. Includes an identity control.")
    return desc, obj(fields, ["cases"])


def _digest(value):
    data = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def compare_behavior(before, after):
    """Paired denominators and signed outcomes for each requested public slice."""
    if len(before) != len(after):
        raise ValueError("different numbers of public cases")
    grouped = {}
    for a, b in zip(before, after, strict=True):
        if (a["case_id"], a["slice"]) != (b["case_id"], b["slice"]):
            raise ValueError("public case or slice differs between paired runs")
        grouped.setdefault(a["slice"], []).append((a, b))
    summary = {}
    for label, pairs in grouped.items():
        fixes = [b["index"] for a, b in pairs if not a["correct"] and b["correct"]]
        losses = [b["index"] for a, b in pairs if a["correct"] and not b["correct"]]
        correct_before = sum(a["correct"] for a, _ in pairs)
        correct_after = sum(b["correct"] for _, b in pairs)
        deltas = [b["margin"] - a["margin"] for a, b in pairs if a["margin"] is not None
                  and b["margin"] is not None]
        summary[label] = {"n": len(pairs), "correct_before": correct_before,
                          "correct_after": correct_after, "correct_delta": correct_after - correct_before,
                          "accuracy_delta": (correct_after - correct_before) / len(pairs),
                          "fixed": fixes, "regressed": losses,
                          "retained_correct": correct_before - len(losses),
                          "mean_margin_change": sum(deltas) / len(deltas) if deltas else None}
    return summary


class _NativeUnit:
    def __init__(self, runner, spec):
        if set(spec) - {"kind", "layer", "unit", "scale"}:
            raise ValueError("native intervention accepts layer, scale and optional unit")
        self.runner = runner
        self.layer = _integer(spec.get("layer"), "layer", 0, len(runner.target.blocks) - 1)
        mlp = getattr(runner.target.blocks[self.layer], "mlp", None)
        kind = type(mlp)
        if (kind.__module__, kind.__name__) not in _NATIVE_MLPS:
            raise ValueError("no verified dense gated MLP down_proj for this block (supports Gemma3MLP or Qwen2MLP)")
        self.module = mlp.down_proj
        if (any(type(m) is not nn.Linear for m in (mlp.gate_proj, mlp.up_proj, self.module))
                or mlp.gate_proj.weight.shape != mlp.up_proj.weight.shape
                or mlp.gate_proj.weight.shape != self.module.weight.T.shape
                or not self.module.weight.is_floating_point()):
            raise ValueError("native unit intervention requires matching dense gate/up/down projections")
        names = [name for name, weight in runner.target.weights().items() if weight is self.module.weight]
        if len(names) != 1:
            raise ValueError("down_proj.weight must map to a single writable target tensor")
        self.name = names[0]
        self.unit = (_integer(spec["unit"], "unit", 0, self.module.in_features - 1)
                     if "unit" in spec else None)
        self.selection = "supplied" if self.unit is not None else "first_prompt_last_token_max_abs"

    def forward(self, ids, scale, observe):
        visits, activation = 0, None

        def scale_input(module, args):
            nonlocal visits, activation
            visits += 1
            if (visits != 1 or len(args) != 1 or not isinstance(args[0], torch.Tensor)
                    or tuple(args[0].shape) != (1, len(ids), module.in_features)):
                raise ValueError("expected one gated MLP input of shape [1, prefix, intermediate_width]")
            z = args[0]
            self.runner.usage["probe_rows"] += len(ids)
            if self.unit is None:
                self.unit = int(z[0, -1].abs().argmax())
            if observe:
                activation = float(z[0, -1, self.unit])
                if not math.isfinite(activation):
                    raise ValueError("non-finite native unit activation")
            # Use exactly the same hook path for both the identity and the treatment.
            replacement = z.clone()
            replacement[..., self.unit] *= scale
            return (replacement,)

        handle = self.module.register_forward_pre_hook(scale_input)
        try:
            logits, _ = self.runner._forward(ids)
            if visits != 1:
                raise ValueError("down_proj was not reached by this target forward")
            return logits, activation
        finally:
            handle.remove()

    def describe(self, scale):
        return {"kind": "native", "layer": self.layer, "unit": self.unit, "selection": self.selection,
                "site": "gated_mlp_down_proj_input", "positions": "all_prefix_positions_each_step",
                "scale": scale, "write": {"tensor": self.name, "operation": "scale",
                                         "selection": [[0, self.module.out_features], self.unit], "factor": scale}}


class _SAEFeature:
    def __init__(self, runner, spec):
        if set(spec) - {"kind", "layer", "feature", "scale"}:
            raise ValueError("SAE intervention accepts feature, scale and optional dictionary layer")
        self.runner = runner
        self.probe = runner._probe({k: v for k, v in spec.items() if k in ("kind", "layer")})
        self.feature, _, _ = runner._intervention({"feature": spec.get("feature"), "scale": spec["scale"]},
                                                 self.probe)

    def forward(self, ids, scale, observe):
        logits, captures = self.runner._forward(
            ids, self.probe, observed=[len(ids) - 1] if observe else [],
            changed=list(range(len(ids))), intervention=(self.feature, "scale", scale),
            capture_feature=self.feature)
        return logits, float(captures[0]) if captures else None

    def describe(self, scale):
        info = {"kind": "sae", "layer": self.probe.layer, "feature": self.feature,
                "site": "post_block_residual", "positions": "all_prefix_positions_each_step",
                "scale": scale, "dictionary_revision": self.runner.sae.revision}
        dictionary_id = getattr(self.runner.sae, "dictionary_id", None)
        if dictionary_id:
            info["dictionary_id"] = dictionary_id
        return info


class BehaviorExperiment:
    def __init__(self, runner, *, internal=False, artifact_dir=None):
        self.runner = runner
        self.internal = internal
        self.artifact_dir = Path(artifact_dir) if artifact_dir is not None else None

    def _prepare(self, cases, max_new_tokens, token_ids):
        _integer(max_new_tokens, "max_new_tokens", 1, MAX_NEW_TOKENS)
        if not isinstance(cases, list) or not 1 <= len(cases) <= MAX_CASES:
            raise ValueError(f"supply 1 to {MAX_CASES} public cases")
        for case in cases:
            if (not isinstance(case, dict) or set(case) != {"slice", "prompt", "answers"}
                    or case["slice"] not in ("improve", "preserve")):
                raise ValueError("each case needs prompt, answers, and slice improve or preserve")
            answers = case["answers"]
            if (not isinstance(answers, list) or not 1 <= len(answers) <= 6
                    or not all(isinstance(a, str) and 0 < len(a) <= 512 and a.strip() for a in answers)):
                raise ValueError("supply 1 to 6 nonempty exact answers of at most 512 characters")
        if token_ids is not None:
            if not isinstance(token_ids, list) or len(token_ids) != 2:
                raise ValueError("token_ids must contain [wanted, alternative]")
            upper = getattr(self.runner.target, "vocab_size", 2**40 + 1) - 1
            for t in token_ids:
                _integer(t, "token_id", 0, upper)
            if token_ids[0] == token_ids[1]:
                raise ValueError("wanted and alternative token IDs must differ")
        return self.runner._encode([c["prompt"] for c in cases], MAX_CASES)

    def _score(self, cases, prefixes, limit, token_ids, site=None, scale=1.):
        rows = []
        for i, (case, prefix) in enumerate(zip(cases, prefixes, strict=True)):
            ids, generated = list(prefix), []
            margin, first_activity = None, None
            for step in range(limit):
                if site is None:
                    logits, _ = self.runner._forward(ids)
                else:
                    logits, activation = site.forward(ids, scale, observe=step == 0)
                    if step == 0:
                        first_activity = activation
                if step == 0 and token_ids is not None:
                    if max(token_ids) >= logits.numel():
                        raise ValueError("token_ids exceed the target vocabulary")
                    margin = float(logits[token_ids[0]]) - float(logits[token_ids[1]])
                predicted = int(logits.argmax())
                generated.append(predicted)
                if predicted in self.runner.target.eos_ids:
                    break
                ids.append(predicted)
            answer = self.runner.target.decode(generated)
            rows.append({"index": i, "case_id": _digest(case)[:16], "slice": case["slice"],
                         "correct": answer.strip() in [a.strip() for a in case["answers"]],
                         "text": answer[:MAX_DISPLAY], "display_truncated": len(answer) > MAX_DISPLAY,
                         "truncated": generated[-1] not in self.runner.target.eos_ids,
                         "generated_tokens": len(generated), "first_token_id": generated[0],
                         "generation_id": _digest(generated)[:16], "margin": margin})
            if site is not None:
                rows[-1]["first_activity"] = first_activity
        return rows

    @torch.inference_mode()
    def evaluate(self, cases, max_new_tokens=12, token_ids=None):
        """Bounded public rows, callable on both sides of a temporary weight edit."""
        with self.runner._lock:
            prefixes = self._prepare(cases, max_new_tokens, token_ids)
            return self._score(cases, prefixes, max_new_tokens, token_ids)

    @torch.inference_mode()
    def run(self, cases, max_new_tokens=12, token_ids=None, intervention=None):
        with self.runner._lock:
            prefixes = self._prepare(cases, max_new_tokens, token_ids)
            site = None
            if intervention is not None:
                if not self.internal:
                    raise ValueError("internal interventions are disabled in this arm")
                if not isinstance(intervention, dict):
                    raise ValueError("expected an intervention object")
                scale = intervention.get("scale")
                if type(scale) not in (int, float) or not -16 <= scale <= 16:
                    raise ValueError("scale must be finite and between -16 and 16")
                kind = intervention.get("kind", "native")
                if kind not in ("native", "sae"):
                    raise ValueError("choose native or sae intervention")
                site = (_NativeUnit if kind == "native" else _SAEFeature)(self.runner, intervention)
            before = self.runner.usage.copy()
            baseline = self._score(cases, prefixes, max_new_tokens, token_ids)
            result = {"baseline": baseline, "revision": self.runner.store.revision}
            if site is not None:
                identity = self._score(cases, prefixes, max_new_tokens, token_ids, site, 1.)
                mismatches = [i for i, (a, b) in enumerate(zip(baseline, identity, strict=True))
                              if a["generation_id"] != b["generation_id"] or a["margin"] != b["margin"]]
                result["identity"] = {"matches": not mismatches, "mismatches": mismatches}
                if mismatches:
                    result["error"] = "Identity intervention changed public outputs; treatment was skipped."
                else:
                    after = self._score(cases, prefixes, max_new_tokens, token_ids, site, scale)
                    result.update(after=after, comparison=compare_behavior(baseline, after))
                result["intervention"] = site.describe(scale)
            result["cost"] = {k: self.runner.usage[k] - v for k, v in before.items()}
            if self.artifact_dir is not None:
                record = {"target": self.runner.target.model_id, "checkpoint": self.runner.target.revision,
                          "cases": cases, "max_new_tokens": max_new_tokens, "token_ids": token_ids, "result": result}
                artifact = Path("behavior") / (_digest(record) + ".json")
                path = self.artifact_dir / artifact
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8")
                result["artifact"] = str(artifact)
            return result
